package com.bank.connector;

import java.sql.Connection;
import java.sql.DriverManager;

public class connector {
	static String url="jdbc:mysql://localhost:3306/bank";
	static String user="root";
	static String password="tiger";
	static Connection connection=null;
	
	public static Connection requestConnection()  {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(url,user,password);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
		
	}

}
