package com.bank.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.bank.DTO.customer;
import com.bank.connector.connector;




public class customerDAOImpl implements customerDAO {

	private Connection con;
	public customerDAOImpl() {
		this.con = connector.requestConnection();
	}
	@Override
	public boolean insertCustomer(customer c) {
		
		PreparedStatement ps = null;
		int res=0;
		String query="insert into bank_1(NAME,PHONE,MAIL,PIN)VALUES(?,?,?,?)";
		
		try {
			ps = con.prepareStatement(query);
			
			ps.setString(1,c.getName());
			ps.setLong(2, c.getPhone());
			ps.setString(3, c.getMail());
			ps.setInt(4,c.getPin());
			res = ps.executeUpdate();
			if (res>0) {
				return true;
				
			}
			else {
				return false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public customer getCustomer(long phone, String mail) {
		
		
		PreparedStatement ps = null;
		int res=0;
		customer c=null;
		
		
		String query="select * from bank_1 where phone=? or mail=?";
		
		try {
			ps= con.prepareStatement(query);
			ps.setLong(1,phone);
			ps.setString(2,mail);
			
			ResultSet rs =ps.executeQuery("select *from bank_1");
			
			
			if (rs.next()) {
				c= new customer();
				c.setAccno(rs.getLong(1));
				c.setName(rs.getString(2));
				c.setPhone(rs.getLong(3));
				c.setMail(rs.getString(4));
				c.setBal(rs.getDouble(5));
				c.setPin(rs.getInt(6));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		// TODO Auto-generated method stub
		return c;
	}
	@Override
	public customer getCustomer(long ACC_NO) {
		PreparedStatement ps = null;
		int res=0;
		customer c_rec=null;
		
		
		String query="select * from bank_1 where ACC_NO=?";
		
		try {
			ps= con.prepareStatement(query);
			ps.setLong(1,ACC_NO);
			
			
			ResultSet rs =ps.executeQuery();
			
			
			if (rs.next()) {
				c_rec= new customer();
				c_rec.setAccno(rs.getLong(1));
				c_rec.setName(rs.getString(2));
				c_rec.setPhone(rs.getLong(3));
				c_rec.setMail(rs.getString(4));
				c_rec.setBal(rs.getDouble(5));
				c_rec.setPin(rs.getInt(6));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		// TODO Auto-generated method stub
		return c_rec;
	}
		// TODO Auto-generated method stub
		
	@Override
	public customer getCustomer(String mail) {
		PreparedStatement ps = null;
		int res=0;
		customer c=null;
		
		
		String query="select * from bank_1 where  mail=?";
		
		try {
			ps= con.prepareStatement(query);
		
			ps.setString(1,mail);
			
			ResultSet rs =ps.executeQuery("select *from bank_1");
			
			
			if (rs.next()) {
				c= new customer();
				c.setAccno(rs.getLong(1));
				c.setName(rs.getString(2));
				c.setPhone(rs.getLong(3));
				c.setMail(rs.getString(4));
				c.setBal(rs.getDouble(5));
				c.setPin(rs.getInt(6));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		// TODO Auto-generated method stub
		return c;
	}
		// TODO Auto-generated method stub
	
	@Override
	public ArrayList<customer> getCustomer() {
		
		PreparedStatement ps=null;
		int res = 0;
		
		ArrayList<customer> customerList= new ArrayList<customer>();
		
		try {
			ps = con.prepareStatement("select *from bank_1");
			
			ResultSet rs = ps.executeQuery();
			
			
			while (rs.next()) {
				customer c =new customer();
				c.setAccno(rs.getLong(1));
				c.setName(rs.getString(2));
				c.setPhone(rs.getLong(3));
				c.setMail(rs.getString(4));
				c.setBal(rs.getDouble(5));
				
				customerList.add(c);
				
				
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		// TODO Auto-generated method stub
		return customerList;
	}
	/**
	 *
	 */
	@Override
	public boolean updateCustomer(customer c) {
		
		PreparedStatement ps=null;
		int res=0;
		String queryString="UPDATE BANK_1 SET NAME=?,PHONE=?,MAIL=?,BALANCE=?,PIN=? WHERE ACC_NO=?";
		
		try {
			con.setAutoCommit(false);
			ps= con.prepareStatement(queryString);
//			System.out.println(queryString);
			
			ps.setString(1,c.getName());
			ps.setLong(2,c.getPhone());
			ps.setString(3,c.getMail());
			ps.setDouble(4,c.getBal());
			ps.setInt(5,c.getPin());
			ps.setLong(6,c.getAccno());
			//System.out.println(c.getAccno()+" "+c.getBal()+" "+c.getMail()+" "+c.getName()+" "+c.getPin()+" "+c.getPhone());
			res = ps.executeUpdate();
		//	System.out.println(res);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (res>0) {
			try {
				con.commit();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;
			
			
		}
		else {
			try {
				con.rollback();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return false;
		}
		
		
		
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean deleteCustomer(customer c) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public customer getCustomer(long accno, int pin) {
		
		PreparedStatement ps = null;
		int res=0;
		customer c=null;
		ResultSet rs=null;
		
		
		String query="select * from bank_1 where acc_no=? AND pin=?";
		
		
		
		try {
			ps= con.prepareStatement(query);
			ps.setLong(1,accno);
			ps.setInt(2,pin);
			rs= ps.executeQuery();
			
			if (rs.next()) {
				c= new customer();
				c.setAccno(rs.getLong(1));
				c.setName(rs.getString(2));
				c.setPhone(rs.getLong(3));
				c.setMail(rs.getString(4));
				c.setBal(rs.getDouble(5));
				c.setPin(rs.getInt(6));
			
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		// TODO Auto-generated method stub
		
		return c;
		
	}
	
}
