package com.bank.DAO;

import java.util.List;

import com.bank.DTO.customer;


public interface customerDAO {
	 public boolean insertCustomer(customer c);
	 public customer getCustomer(long accno,int pin);
	 public customer getCustomer(long phone,String mail);
	 public  customer getCustomer(long Acc_no);
	 public customer getCustomer(String mail);
	 public List getCustomer();
	 public  boolean updateCustomer(customer c);
	  public  boolean deleteCustomer(customer c);
	  

}
