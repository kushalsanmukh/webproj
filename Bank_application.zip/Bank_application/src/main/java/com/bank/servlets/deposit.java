package com.bank.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;

import com.bank.DAO.customerDAO;
import com.bank.DAO.customerDAOImpl;
import com.bank.DTO.customer;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/deposit")

public class deposit extends HttpServlet {
	
//	static customer customer=login.getObject();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
//		customer customer=null;
	
//		customer  c= (customer) req.getAttribute("cust1");
		HttpSession session=req.getSession();
		
		customer customer= (com.bank.DTO.customer) session.getAttribute("customer");
		
		
		
		PrintWriter out =resp.getWriter();
		customerDAO cDao = new customerDAOImpl();
		
		
//		
//		String acc_no=req.getParameter("acc_no");
		String pin = req.getParameter("pin");
		String amount=req.getParameter("amount");
		
//		String name=req.getParameter("name");
		
//		long acc_no_set= c.getAccno();
//		int pin_set = Integer.parseInt(pin);
		Double amount_set= Double.parseDouble(amount);
//		customer=cDao.getCustomer(acc_no_set, pin_set);
		
		
		
		if (customer!=null) {
			Double amt= customer.getBal()+amount_set;
			
			customer.setBal(amt);
			
		boolean res = cDao.updateCustomer(customer);
		
		if (res) {
			out.println("amount is deposit "+customer.getBal());
			
		}
		else {
			out.println(" error not deposit");
		}
			
			
			
		}
		else {
			out.println("no user found");
		}
		
		
	}

}
