package com.bank.servlets;

import java.io.BufferedReader;
import java.io.IOException;

import java.io.PrintWriter;

import com.bank.DAO.customerDAO;
import com.bank.DAO.customerDAOImpl;
import com.bank.DTO.customer;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/login")

public class login extends HttpServlet{
	
//	static customer customer;
//	
// public	static customer getObject() {
//		
//		return customer;
//	}
 
 
	
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		HttpSession session=req.getSession();
		
		
		
		String acc_no=req.getParameter("acc_no");
		String pin = req.getParameter("password");
		
		
		int pin_1 = Integer.parseInt(pin);
		int acc = Integer.parseInt(acc_no);
		
		
		
		customer customer = new customer();
		customerDAO cDao = new customerDAOImpl();
		PrintWriter out=resp.getWriter();
		
		customer = cDao.getCustomer(acc, pin_1);
//		req.setAttribute("cust",customer);
		
		if (customer!=null) {
			String name=customer.getName();
			
			req.setAttribute("name",name);
			String filepath="App.jsp";
			RequestDispatcher re_d= req.getRequestDispatcher(filepath);
			re_d.forward(req, resp);
//			out.println("<h1> welcome</h1>"+customer.getName());
//			out.println(customer.getAccno());
//			out.println(customer.getMail());
//			
//			out.println(customer.getPhone());
//			
			
			
			
		}
		else {
			out.println("no user error");
		}
		
		
		
		session.setAttribute("customer",customer);
		
		
		
		
		
		
	}

}
