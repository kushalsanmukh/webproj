package com.bank.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import com.bank.DTO.customer;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class Reset extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session= req.getSession();
		PrintWriter out = resp.getWriter();
		
		String action=req.getParameter("action");
		String mail= req.getParameter("mail");
		String phone= req.getParameter("phone");
		String New_pin= req.getParameter("New_pin");
		String c_pin= req.getParameter("c_pin");
		
		long phone1=Long.parseLong(phone);
		
		int New_pin1=Integer.parseInt(New_pin);
		int c_pin1=Integer.parseInt(c_pin);
		customer customer= (com.bank.DTO.customer) session.getAttribute("customer");
		
		if (action.equals("yes")) {
			
			if (phone1==customer.getPhone() && mail.equals(customer.getMail())) {
				System.out.println("set new pin");
				int pin = scanner.nextInt();
				System.out.println("confirm the pin");
				int confirmpin = scanner.nextInt();
				if (pin==confirmpin) {
					c.setPin(pin);
					boolean res = cDao.updateCustomer(c);
					if(res) {
						System.out.println("pin set");
						
					}
					else {
						System.out.println("Error");
					}
					
				}
				else {
					System.out.println("pin missmatch");
				}
				
				
			}
			else {
				System.out.println("phone number or mail is incorrect");
			}
			
		}
		else if(action.equals("NO")){
			
		}
		
		
	}
	

}
