package com.bank.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import com.bank.DTO.customer;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/App")

public class App extends HttpServlet {
	
//	static customer customer = login.getObject();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
//		customer c= (customer) req.getAttribute("cust");
//		
//		req.setAttribute("cust1", c);
		HttpSession session=req.getSession();
		
		customer customer= (com.bank.DTO.customer) session.getAttribute("customer");
		
		String action=req.getParameter("action");
		PrintWriter out=resp.getWriter();
		
		if (action.equals("CheckBal")) {
			
			out.println(customer.getName()+"your balance is"+customer.getBal());
		}
		else if(action.equals("Transfer_Amount")){
			
			RequestDispatcher requestDispatcher = req.getRequestDispatcher("TransferAmount.jsp");
			requestDispatcher.forward(req, resp);
			 
		}
		
		else {
			
			out.println("error");

		}
		
//		String filepath="deposit.jsp";
//		RequestDispatcher re_d= req.getRequestDispatcher(filepath);
//		re_d.forward(req, resp);
		// it will forward the page
		
	
	}
	

}
