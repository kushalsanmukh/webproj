package com.bank.servlets;

import java.io.IOException;
import java.io.PrintWriter;



import com.bank.DAO.customerDAO;
import com.bank.DAO.customerDAOImpl;
import com.bank.DTO.customer;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/signup")

public class signup extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String name=req.getParameter("name");
		String mail=req.getParameter("mail");
		String mobile=req.getParameter("p_no");
		String t_pin=req.getParameter("pin");
		String tc_pin=req.getParameter("c_pin");
		
		long phone = Long.parseLong(mobile);
		int pin = Integer.parseInt(t_pin);
		int c_pin = Integer.parseInt(tc_pin);
		
		
		customer customer = new customer();
		customerDAO cDao = new customerDAOImpl();
		PrintWriter out=resp.getWriter();
		customer.setName(name);
		customer.setPhone(phone);
		customer.setMail(mail);
		
		if (t_pin.equals(tc_pin)) {
			customer.setPin(pin);
			boolean res =cDao.insertCustomer(customer);
			
			if (res) {
				customer=cDao.getCustomer(phone, mail);
				out.println("<h1> hi"+name+"your acc is created  your acc_no is"+customer.getAccno());
				
			}
			else {
				out.println("<h1> failed to create the account. Try again</h1>");
			}
			
		}
		else {
			out.println("password mismatch");
		}
		
		
	}

}
