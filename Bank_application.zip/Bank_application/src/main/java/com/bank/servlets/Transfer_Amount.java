package com.bank.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import com.bank.DAO.customerDAO;
import com.bank.DAO.customerDAOImpl;
import com.bank.DTO.customer;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/Transfer_Amount")

public class Transfer_Amount  extends HttpServlet{
	@Override
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out = resp.getWriter();
		
		String value= req.getParameter("Transfer_Amount");
		
		String acc_no= req.getParameter("Acc_no");
		String amount=req.getParameter("amount");
		String pin= req.getParameter("pin");
		
		long acc_no1=Long.parseLong(acc_no);
		double amount1= Double.parseDouble(amount);
		int pin1= Integer.parseInt(pin);
		
		customer Transfer_customer=new customer();
		HttpSession session=req.getSession();
		
		customer customer= (com.bank.DTO.customer) session.getAttribute("customer");
		
		customerDAO cDao=new customerDAOImpl();
		
		Transfer_customer= cDao.getCustomer(acc_no1);
		
		
		if (value.equals("Transfer_Amount")) {
			
		
		if (customer.getAccno()!=Transfer_customer.getAccno()&& customer.getBal()>0&&customer.getBal()>=amount1&&amount1>0) {
			
			if (customer.getAccno()!=pin1) {
				customer.setBal(customer.getBal()-amount1);
				boolean c_res= cDao.updateCustomer(customer);
				
				
				Transfer_customer.setBal(Transfer_customer.getBal()+amount1);
				boolean receiver_res=cDao.updateCustomer(Transfer_customer);
				
				if (receiver_res&&c_res) {
					out.println("amount transfer done"+customer.getAccno()+"   		"+customer.getBal());
					out.println("amount transfer done"+Transfer_customer.getAccno()+"		"+Transfer_customer.getBal());
					
					
				}
				else {
					out.println("error");
				}
			}
			else {
				out.println("pin is incorrect");
			}
			
			
		} else {
			
			out.println("error");

		}
	}
	}
		
	

}
